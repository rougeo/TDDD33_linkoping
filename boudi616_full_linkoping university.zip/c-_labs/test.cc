#include<iostream>
#include<cstdio>
#include<iomanip>

int main()
{
  int a;
  using namespace std;

  cin>>setw(2)>>setprecision(2)>>a;

  std::cout << a << std::endl;
  return 0;
}
